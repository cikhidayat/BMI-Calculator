======================================
 BMI Calculator Versi 1.0
======================================
Created by : Rahmat Hidayat
Website    : www.cikhidayat.com

Gunakan program ini dengan sebaik mungkin ^_^